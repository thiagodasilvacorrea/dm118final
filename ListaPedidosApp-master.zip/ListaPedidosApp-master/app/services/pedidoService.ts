import {Injectable} from '@angular/core';
import { Pedido } from '../model/pedido';

@Injectable()
export class PedidoService {

    preencherPedidoList(data:any):Array<Pedido> {
       let jsonBody = data._body;
       let jsonList = JSON.parse(jsonBody);
       let pedido:Pedido;
       let pedidoList = new Array<Pedido>();
       for (let json of jsonList) {
         console.log(jsonList);
         console.log(json);
         pedido = new Pedido(json.data_emissao,json.id,json.frete,json.vendedor,json.transportadora,json.status_pedido,json.usuario_matricula);
         console.log(pedido);
         pedidoList.push(pedido);
       }
       return pedidoList
    }

    alterarPedido(data:any):Pedido {
       let jsonBody = data._body;
       let jsonList = JSON.parse(jsonBody);
       let pedido:Pedido
       return pedido
    } 
  }