
export enum SettingsEnum{
	API_PEDIDO_URL = <any> 'http://tmebr.esy.es/apis/cardapio/listar/2696'
}