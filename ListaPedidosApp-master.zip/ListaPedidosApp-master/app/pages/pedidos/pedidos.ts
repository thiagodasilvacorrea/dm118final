import { Component} from '@angular/core';
import { NavController } from 'ionic-angular';
import {Http, Headers, RequestOptions, Response} from '@angular/http';
import {SettingsEnum} from '../../enum/SettingsEnum';
import {UtilService} from '../../services/utilService';
import {PedidoService} from '../../services/pedidoService';
import { Pedido } from '../../model/pedido';


@Component({
    templateUrl: 'build/pages/pedidos/pedidos.html'
})
export class PedidosPage {
 private apiPedidoUrl:string;
    private mostrarDetalhes:boolean;
    private selectedPedido:Pedido ;
    private navController: NavController
    private pedidosList:Array<Pedido>;
    private edit :boolean;
    private putPedidoUrl:string;

    constructor(private nav: NavController,
    private pedidoService: PedidoService,
    private http:Http) {
        this.apiPedidoUrl = UtilService.getEnumString(SettingsEnum, SettingsEnum.API_PEDIDO_URL);
        this.listarPedidos();
        this.mostrarDetalhes = false;
        this.edit =false;
        this.selectedPedido = new Pedido("", null, "", "", "", "", "");
    }

    listarPedidos(){
         let creds = "";
         this.pedidosList = new Array<Pedido>();
            let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
            let options = new RequestOptions({ headers: headers });
            this.http.get(this.apiPedidoUrl).subscribe(
                        data => this.preencherPedidoList(data),
                        err => console.log()
            );
    }
    private preencherPedidoList(data: any){
       this.pedidosList = this.pedidoService.preencherPedidoList(data);
    }

    viewPedidos(selectedPedido: Pedido){
        this.selectedPedido = selectedPedido;
        this.mostrarDetalhes = true;
    }
        viewEditPedidos(selectedPedido: Pedido){
        this.selectedPedido = selectedPedido;
        this.mostrarDetalhes = false;
        this.edit = true;
        

    }

      private alterar()

         {
            
            this.putPedidoUrl = '/rest/alterarStatus/'+this.selectedPedido.getId();
            let headers = new Headers({ 'Content-Type':
            'application/json' });
            let statusPedido = "transporte";
            let pedidoJson = JSON.stringify({"statusPedido": statusPedido, "matricula":this.selectedPedido.getUsuarioMatricula()});
            let options = new RequestOptions({ headers: headers });
            this.http.put(this.putPedidoUrl, pedidoJson, options).subscribe(
                        data => this.pedidoService.alterarPedido(data),
                        err => console.log()
            );
         }


        private cancelar()
        {
            
            this.edit = false;
        
        }
    getMostrarDetalhes() : boolean{
        return this.mostrarDetalhes;
    }
    setMostrarDetalhes(mostrarDetalhes: boolean){
        this.mostrarDetalhes = mostrarDetalhes;
    }

     getEdit() : boolean{
        return this.edit;
    }
    setEdit(edit: boolean){
        this.edit = edit;
    }

    getSelectedPedido() : Pedido{
        return this.selectedPedido;
    }
    setSelectedPedido(selectedPedido: Pedido){
        this.selectedPedido = selectedPedido;
    }

    getPedidosList() : Array<Pedido>{
        return this.pedidosList;
    }
    setPedidosList(pedidosList: Array<Pedido>){
        this.pedidosList = pedidosList;
    }

  }

