export class Pedido{

	private data_emissao: string;
    private id: number;
    private data_atualizacao: string;
    private frete: string;
    private vendedor: string;
    private transportadora: string;
    private status_pedido: string;
    private usuario_matricula: string;

    constructor(data_emissao: string, id:number, frete:string, vendedor: string, transportadora:string, status_pedido:string,
    usuario_matricula:string){
      this.id = id;
      this.data_emissao = data_emissao;
      this.frete = frete;
      this.vendedor = vendedor;
      this.transportadora = transportadora;
      this.status_pedido = status_pedido;
      this.usuario_matricula = usuario_matricula;
    }
    
    public getDataEmissao():string{
        return this.data_emissao;
    }
    public getId():number{
        return this.id;
    }
    public getDataAtualizacao():string{
        return this.data_atualizacao;
    }
    public getFrete():string{
        return this.frete;
    }
    public getVendedor():string{
        return this.vendedor;
    }
    public getTransportadora():string{
        return this.transportadora;
    }
    public getStatusPedido():string{
        return this.status_pedido;
    }
    public getUsuarioMatricula():string{
        return this.usuario_matricula;
    }
    public setDataEmissao(data_emissao: string){
        this.data_emissao = data_emissao;
    }
    public setDataAtualizacao(data_atualizacao: string){
        this.data_atualizacao = data_atualizacao;
    }
    public setId(id: number){
        this.id = id;
    }
    public setFrete(frete: string){
        this.frete = frete;
    }
    public setVendedor(vendedor: string){
        this.vendedor = vendedor;
    }
    public setTransportadora(transportadora: string){
        this.transportadora = transportadora;
    }
    public setStatusPedido(status_pedido: string){
        this.status_pedido = status_pedido;
    }
    public setUsuarioMatricula(usuario_matricula: string){
        this.usuario_matricula = usuario_matricula;
    }
}