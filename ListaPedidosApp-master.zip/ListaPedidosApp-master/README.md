# Ionic 2

#Dependências
npm install

#Executando no navegador
ionic run browser

